package Product3.FunctionalProgramming;

public class Car {
    public Car() {
    }
}
